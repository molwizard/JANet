package org.BioLayoutExpress3D.Graph.Camera.CameraUI;

/**
* The GraphAnaglyphGlassesTypes enumeration class holds information about the type of glasses.
*
*
* @author Thanos Theo 2011
* @version 3.0.0.0
*
*/

public enum GraphAnaglyphGlassesTypes { RED_BLUE, RED_GREEN, RED_CYAN, BLUE_RED, GREEN_RED, CYAN_RED }