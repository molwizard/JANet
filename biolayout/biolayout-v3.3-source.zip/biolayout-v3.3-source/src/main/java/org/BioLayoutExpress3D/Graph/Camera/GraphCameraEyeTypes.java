package org.BioLayoutExpress3D.Graph.Camera;

/**
* The GraphCameraEyeTypes enumeration class holds information about the type of camera eyes.
*
*
* @author Thanos Theo 2011
* @version 3.0.0.0
*
*/

public enum GraphCameraEyeTypes { LEFT_EYE, CENTER_VIEW, RIGHT_EYE }