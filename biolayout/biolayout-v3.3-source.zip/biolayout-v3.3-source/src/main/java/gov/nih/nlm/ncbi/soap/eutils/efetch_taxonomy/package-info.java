@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.ncbi.nlm.nih.gov/soap/eutils/efetch_taxonomy", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package gov.nih.nlm.ncbi.soap.eutils.efetch_taxonomy;
